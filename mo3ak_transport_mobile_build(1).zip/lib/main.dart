import 'package:flutter/material.dart';

void main() => runApp(const Mo3akApp());

class Mo3akApp extends StatelessWidget {
  const Mo3akApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'معاك للنقل',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087E70)),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const QuoteScreen(),
    );
  }
}

class QuoteScreen extends StatefulWidget {
  const QuoteScreen({super.key});
  @override
  State<QuoteScreen> createState() => _QuoteScreenState();
}

class _QuoteScreenState extends State<QuoteScreen> {
  final distanceController = TextEditingController(text: '200');
  final completedController = TextEditingController(text: '0');
  String vehicle = 'ربع نقل';
  String tripType = 'سفر';
  bool useDiscount = false;

  double get basePrice {
    final km = double.tryParse(distanceController.text) ?? 0;
    if (tripType == 'داخل القاهرة والجيزة') return 2000;
    if (km <= 200) return 2000;
    return 2000 + ((km - 200) * 10);
  }

  bool get eligible {
    final count = int.tryParse(completedController.text) ?? 0;
    return count >= 10 && useDiscount;
  }

  double get finalPrice => basePrice * (eligible ? 0.9 : 1);
  double get commission => finalPrice * 0.10;
  double get driverNet => finalPrice - commission;

  @override
  void dispose() {
    distanceController.dispose();
    completedController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('معاك للنقل 🚚'),
          centerTitle: true,
        ),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            Card(
              color: Theme.of(context).colorScheme.primaryContainer,
              child: const Padding(
                padding: EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('أهلاً بيك في معاك للنقل', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
                    SizedBox(height: 6),
                    Text('احسب تكلفة طلب النقل — نسخة أولية للتجربة'),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: vehicle,
              decoration: const InputDecoration(labelText: 'نوع السيارة', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'ربع نقل', child: Text('ربع نقل')),
                DropdownMenuItem(value: 'نقل مبرد', child: Text('نقل مبرد')),
              ],
              onChanged: (v) => setState(() => vehicle = v ?? vehicle),
            ),
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              value: tripType,
              decoration: const InputDecoration(labelText: 'نوع الرحلة', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'سفر', child: Text('سفر')),
                DropdownMenuItem(value: 'داخل القاهرة والجيزة', child: Text('داخل القاهرة والجيزة')),
              ],
              onChanged: (v) => setState(() => tripType = v ?? tripType),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: distanceController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'المسافة بالكيلومتر (للسفر)', border: OutlineInputBorder()),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: completedController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'عدد الطلبات المكتملة السابقة', border: OutlineInputBorder()),
              onChanged: (_) => setState(() {}),
            ),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('تفعيل خصم العميل 10%'),
              subtitle: const Text('يُتاح بعد 10 طلبات مكتملة، على الطلب التالي'),
              value: useDiscount,
              onChanged: (v) => setState(() => useDiscount = v),
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    _line('السعر قبل الخصم', basePrice),
                    _line('الخصم', eligible ? basePrice * 0.10 : 0),
                    const Divider(),
                    _line('إجمالي العميل', finalPrice, bold: true),
                    _line('عمولة التطبيق 10%', commission),
                    _line('صافي السائق', driverNet, bold: true),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'تنبيه: دي نسخة واجهة وحسابات تجريبية فقط. لسه مفيش خرائط فعلية أو تسجيل حسابات أو قاعدة بيانات أو دفع إلكتروني أو استقبال طلبات حقيقية.',
              style: TextStyle(color: Colors.black54),
            ),
          ],
        ),
      ),
    );
  }

  Widget _line(String label, double amount, {bool bold = false}) {
    final style = TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 17 : 15);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Expanded(child: Text(label, style: style)),
          Text('${amount.toStringAsFixed(0)} جنيه', style: style),
        ],
      ),
    );
  }
}
